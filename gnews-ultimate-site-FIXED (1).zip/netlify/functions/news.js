
import fetch from "node-fetch";

export async function handler(event) {
  try {
    const q = event.queryStringParameters?.q || "technology";
    const API_KEY = process.env.GNEWS_API_KEY;

    if (!API_KEY) {
      return { statusCode: 500, body: "Missing GNEWS_API_KEY" };
    }

    const res = await fetch(`https://gnews.io/api/v4/search?q=${q}&lang=en&max=10&apikey=${API_KEY}`);
    const data = await res.json();

    return {
      statusCode: 200,
      body: JSON.stringify(data)
    };
  } catch (err) {
    return { statusCode: 500, body: err.toString() };
  }
}
