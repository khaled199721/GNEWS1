
import React, { useEffect, useState } from "react";
import Ticker from "./components/Ticker";
import Categories from "./components/Categories";
import Ads from "./components/Ads";

export default function App() {
  const [articles, setArticles] = useState([]);
  const [category, setCategory] = useState("technology");

  const fetchNews = async () => {
    const res = await fetch(`/.netlify/functions/news?q=${category}`);
    const data = await res.json();
    setArticles(data.articles || []);
  };

  useEffect(()=>{ fetchNews(); }, [category]);

  return (
    <div style={{ maxWidth:1100, margin:"auto", fontFamily:"Arial" }}>

      <h1 style={{ textAlign:"center" }}>Global News Portal</h1>
      <p style={{ textAlign:"center" }}>Powered by CozyRilakumma Group</p>

      <Ticker articles={articles} />
      <Categories setCategory={setCategory} />
      <Ads />

      {articles.map((a,i) => (
        <article key={i} style={{ marginBottom:25 }}>
          <h2>{a.title}</h2>
          {a.image && <img src={a.image} style={{ width:"100%" }} />}
          <p>{a.description}</p>
          <a href={a.url} target="_blank">Read More</a>
          <hr/>
        </article>
      ))}

      <Ads />
    </div>
  );
}
