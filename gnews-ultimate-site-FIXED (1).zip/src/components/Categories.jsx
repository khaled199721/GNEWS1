
export default function Categories({ setCategory }) {
  const cats = ["technology","world","sports","business","science","health"];

  return (
    <div style={{ display:"flex", gap:10, justifyContent:"center", margin:20 }}>
      {cats.map(c => (
        <button key={c} onClick={()=>setCategory(c)}>{c}</button>
      ))}
    </div>
  );
}
