
export default function Ticker({ articles }) {
  return (
    <div style={{ background:"#000", color:"white", padding:10 }}>
      <marquee>
        {articles.slice(0,8).map(a => a.title).join(" 🔥 ")}
      </marquee>
    </div>
  );
}
