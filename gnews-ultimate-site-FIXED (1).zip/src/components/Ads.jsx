
import { useEffect } from "react";

export default function Ads() {
  useEffect(() => {
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch (e) {}
  }, []);

  return (
    <ins className="adsbygoogle"
      style={ display: "block" }
      data-ad-client="ca-pub-4336964272060142"
      data-ad-slot="0000000000"
      data-ad-format="auto"
      data-full-width-responsive="true">
    </ins>
  );
}
