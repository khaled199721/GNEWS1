
export default function Ticker({ articles }) {
  return (
    <div className="ticker">
      <div className="ticker-content">
        {articles.map((a, i) => (
          <span key={i}>🔥 {a.title} &nbsp;&nbsp;&nbsp;</span>
        ))}
      </div>
    </div>
  )
}
