
import { useEffect, useState } from "react";
import Head from "next/head";
import Script from "next/script";
import Ticker from "../components/Ticker";

export default function Home() {
  const [articles, setArticles] = useState([]);
  const [page, setPage] = useState(1);

  useEffect(() => {
    loadNews();
  }, []);

  const loadNews = () => {
    fetch(`/api/news?lang=ar`)
      .then(res => res.json())
      .then(data => setArticles(prev => [...prev, ...data]));
  };

  useEffect(() => {
    const handleScroll = () => {
      if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 500) {
        loadNews();
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <Head>
        <title>VALUTED KICKS NEWS – The Viral Tagline</title>
        <meta name="description" content="Breaking viral news updated hourly." />
      </Head>

      <header className="header">
        <h1>VALUTED KICKS NEWS</h1>
        <p className="tagline">The Viral Tagline</p>
      </header>

      <Ticker articles={articles.slice(0,5)} />

      <div className="container">
        {articles.map((article, index) => (
          <div key={index} className="card">
            <img src={article.image} />
            <div className="content">
              <span className="badge">BREAKING</span>
              <h2>{article.title}</h2>
              <p>{article.description}</p>
              <a href={article.url} target="_blank">Read More →</a>
            </div>

            {(index + 1) % 3 === 0 && (
              <div className="incontent-ad">
                <Script
                  src="https://YOUR-BANNER-AD.js"
                  strategy="afterInteractive"
                />
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="sticky-ad">
        <Script
          src="https://YOUR-MOBILE-BANNER.js"
          strategy="afterInteractive"
        />
      </div>
    </>
  );
}
