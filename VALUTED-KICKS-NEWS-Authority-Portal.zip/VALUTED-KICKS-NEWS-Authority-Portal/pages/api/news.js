
let cache = {};
let lastFetch = {};

export default async function handler(req, res) {
  const lang = req.query.lang || "ar";
  const now = Date.now();

  if (!cache[lang] || now - (lastFetch[lang] || 0) > 3600000) {
    const response = await fetch(
      `https://gnews.io/api/v4/top-headlines?lang=${lang}&max=10&apikey=${process.env.GNEWS_API_KEY}`
    );
    const data = await response.json();
    cache[lang] = data.articles;
    lastFetch[lang] = now;
  }

  res.status(200).json(cache[lang] || []);
}
