
import '../styles/globals.css'
import Script from 'next/script'

export default function MyApp({ Component, pageProps }) {
  return (
    <>
      <Script
        src="https://pl28749930.effectivegatecpm.com/30/b2/dd/30b2ddd5841c7a135d3feff4ba662b42.js"
        strategy="afterInteractive"
      />
      <Component {...pageProps} />
    </>
  )
}
